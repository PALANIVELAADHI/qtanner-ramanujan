import numpy as np, pytest, sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from qtanner.group import PSL, PGL
from qtanner.generators import sample_pair, spectral_ratio, random_symmetric_set
from qtanner.localcodes import best_local_code, random_local_code
from qtanner.complex_dc import build_complex
from qtanner.code import QuantumTannerCode
from qtanner import gf2
import scipy.sparse as sp


@pytest.mark.parametrize("q", [5, 7])
def test_group_axioms(q):
    for G, N in ((PSL(q), q * (q * q - 1) // 2), (PGL(q), q * (q * q - 1))):
        assert G.N == N
        rng = np.random.default_rng(0)
        x, y, z = rng.integers(0, G.N, (3, 200))
        assert (G.mult[G.mult[x, y], z] == G.mult[x, G.mult[y, z]]).all()      # associativity
        assert (G.mult[x, G.inv[x]] == G.identity).all()
    assert len(set(PSL(5).class_label)) == 5 and len(set(PSL(7).class_label)) == 6   # A5, PSL(2,7)


def test_pgl_index2():
    G = PGL(5)
    assert G.odd.sum() == G.N // 2
    ev = ~G.odd
    assert ev[G.mult[np.where(ev)[0][:, None], np.where(ev)[0][None, :]]].all()       # subgroup


def test_generators_conditions():
    G = PSL(5); rng = np.random.default_rng(1)
    A, B = sample_pair(G, 6, rng)
    assert len(A) == len(B) == 6 and G.generates(A) and G.generates(B)
    assert set(G.inv[A]) == set(A) and set(G.inv[B]) == set(B)
    assert not set(G.class_label[A]) & set(G.class_label[B])
    assert spectral_ratio(G, A)[1] > 0.5


@pytest.mark.parametrize("variant,q,D,kA,kB", [("dc", 5, 6, 4, 2), ("dc", 5, 8, 5, 3), ("dc", 7, 6, 4, 2), ("bip", 5, 6, 4, 2), ("bip", 5, 8, 3, 5)])
def test_commutation_rate_and_logicals(variant, q, D, kA, kB):
    G = PSL(q) if variant == "dc" else PGL(q); rng = np.random.default_rng(q + D)
    A, B = sample_pair(G, D, rng, bipartite=variant == "bip")
    CA, CB = best_local_code(D, kA, rng), best_local_code(D, kB, rng)
    cx = build_complex(G, A, B, variant == "bip")
    n0 = G.N if variant == "dc" else G.N // 2          # |V0|: all of PSL, or the index-2 subgroup
    assert cx.n == n0 * D * D // 2
    code = QuantumTannerCode.build(cx, CA, CB)                 # raises if H_X H_Z^T != 0
    assert code.commutes()
    assert code.k >= code.counting_bound_k()
    assert len(code.logical_x) == len(code.logical_z) == code.k
    LZ, LX = code.logical_dense("z"), code.logical_dense("x")
    P = LX.astype(int) @ LZ.T.astype(int) % 2                  # pairing must be non-degenerate
    assert gf2.rank(gf2.csr_to_ints(sp.csr_matrix(P))) == code.k
    assert not (code.HZ @ LX.T % 2).any() and not (code.HX @ LZ.T % 2).any()


def test_local_code_distances():
    rng = np.random.default_rng(0)
    c = random_local_code(8, 4, rng)
    assert c.G.shape == (4, 8) and c.H.shape == (4, 8) and not (c.G @ c.H.T % 2).any()


def test_conjugate_sets_rejected():
    G = PSL(5); a = np.array([x for x in range(G.N) if x != G.identity][:1])
    with pytest.raises(ValueError):
        build_complex(G, np.array([a[0], G.inv[a[0]]]), np.array([a[0], G.inv[a[0]]]))
