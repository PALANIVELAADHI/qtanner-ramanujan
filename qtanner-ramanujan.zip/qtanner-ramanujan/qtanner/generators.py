"""Random symmetric generating sets, validity statistics and spectral screening."""
from __future__ import annotations
import numpy as np
from .group import Group


def cayley_adjacency(G: Group, S) -> np.ndarray:
    M = np.zeros((G.N, G.N))
    rows = np.arange(G.N)
    for s in S:
        M[rows, G.mult[:, s]] += 1.0
    return M


def spectral_ratio(G: Group, S) -> tuple[float, float]:
    """Return (lambda(S), rho(S)=lambda/(2 sqrt(Delta-1))); trivial +-Delta excluded."""
    D = len(S)
    ev = np.linalg.eigvalsh(cayley_adjacency(G, S))
    lam = float(np.max(np.abs(ev[np.abs(ev) < D - 1e-9])))
    return lam, lam / (2.0 * np.sqrt(D - 1))


def is_ramanujan(G: Group, S) -> bool:
    return spectral_ratio(G, S)[1] <= 1.0 + 1e-12


def random_symmetric_set(G: Group, delta: int, rng, pool: np.ndarray | None = None,
                         max_tries: int = 2000):
    """Random inverse-closed subset of `pool` (default G minus identity), size exactly delta."""
    if pool is None:
        pool = np.array([x for x in range(G.N) if x != G.identity])
    pool = np.asarray(pool)
    poolset = set(pool.tolist())
    for _ in range(max_tries):
        S: set = set()
        order = rng.permutation(pool)
        for x in order:
            x = int(x)
            if x in S:
                continue
            new = {x, int(G.inv[x])}
            if len(S | new) <= delta:
                S |= new
            if len(S) == delta:
                break
        if len(S) == delta and all(int(G.inv[s]) in S for s in S):
            return np.array(sorted(S), dtype=np.int32)
    return None


def _class_groups(G: Group) -> np.ndarray:
    """Label of the inverse-closed 'class group' of each element (class(x) U class(x^-1))."""
    lab = G.class_label.copy()
    comp = np.minimum(lab, lab[G.inv])
    return comp


def sample_pair(G: Group, delta: int, rng, bipartite: bool = False, max_tries: int = 500):
    """Draw (A,B): inverse-closed, size delta, each generates G, no element of A conjugate to
    an element of B.  Whole class groups are assigned to one side (as in the paper), so the
    conjugacy condition holds by construction.  With bipartite=True (PGL only) both sets lie
    in G minus the index-2 subgroup (det non-square)."""
    allowed = np.array([x for x in range(G.N) if x != G.identity and
                        (not bipartite or G.odd[x])])
    comp = _class_groups(G)
    groups = np.unique(comp[allowed])
    for _ in range(max_tries):
        side = {int(c): int(rng.integers(2)) for c in groups}
        poolA = np.array([x for x in allowed if side[int(comp[x])] == 0])
        poolB = np.array([x for x in allowed if side[int(comp[x])] == 1])
        if len(poolA) < delta or len(poolB) < delta:
            continue
        A = random_symmetric_set(G, delta, rng, poolA)
        B = random_symmetric_set(G, delta, rng, poolB)
        if A is None or B is None:
            continue
        if G.generates(A) and G.generates(B):
            return A, B
    raise RuntimeError("could not sample a valid (A,B) pair")


def draw_validity_stats(G: Group, delta: int, rng, trials: int = 400) -> dict:
    """Fractions of *independent* random symmetric pairs that (i) fail to generate G and
    (ii) share a conjugacy class (Section 'Statistics, invalid draws')."""
    nogen = share = 0
    lab = G.class_label
    for _ in range(trials):
        A = random_symmetric_set(G, delta, rng)
        B = random_symmetric_set(G, delta, rng)
        nogen += int(not (G.generates(A) and G.generates(B)))   # A and B counted jointly
        share += int(len(set(lab[A]) & set(lab[B])) > 0)
    return {"q": G.q, "delta": delta, "trials": trials,
            "frac_not_generating": nogen / trials, "frac_shared_class": share / trials}
