"""Random binary local codes with exact distances (by enumeration)."""
from __future__ import annotations
from dataclasses import dataclass
import numpy as np


@dataclass
class LocalCode:
    n: int
    k: int
    G: np.ndarray        # (k, n) generator matrix of C
    H: np.ndarray        # (n-k, n) generator of the dual C^perp (= parity-check of C)
    d: int               # exact distance of C  (n+1 if k == 0)
    dperp: int           # exact distance of C^perp (n+1 if k == n)

    @property
    def score(self):
        return self.d + self.dperp


def _min_distance(Gm: np.ndarray) -> int:
    k, n = Gm.shape
    if k == 0:
        return n + 1
    msgs = ((np.arange(1, 2 ** k)[:, None] >> np.arange(k)) & 1).astype(np.uint8)
    return int((msgs @ Gm % 2).sum(axis=1).min())


def random_local_code(n: int, k: int, rng) -> LocalCode:
    """Random systematic [n,k] code G=[I|P] with a random column permutation."""
    P = rng.integers(0, 2, size=(k, n - k), dtype=np.uint8)
    G = np.concatenate([np.eye(k, dtype=np.uint8), P], axis=1)
    H = np.concatenate([P.T, np.eye(n - k, dtype=np.uint8)], axis=1)
    perm = rng.permutation(n)
    G, H = G[:, perm], H[:, perm]
    return LocalCode(n, k, G, H, _min_distance(G), _min_distance(H))


def best_local_code(n: int, k: int, rng, tries: int = 60) -> LocalCode:
    """Keep the draw maximising min(d, d^perp), then d + d^perp (paper's rule)."""
    best, key = None, None
    for _ in range(tries):
        c = random_local_code(n, k, rng)
        kk = (min(c.d, c.dperp), c.d + c.dperp)
        if key is None or kk > key:
            best, key = c, kk
    return best


def local_code_pool(n: int, k: int, count: int, rng) -> list[LocalCode]:
    return [random_local_code(n, k, rng) for _ in range(count)]
