"""Heuristic and MILP upper bounds on logical weights (none certified)."""
from __future__ import annotations
import numpy as np
import scipy.sparse as sp
from scipy.optimize import milp, LinearConstraint, Bounds


def greedy_descent(x: int, stab_rows: list[int], rounds: int = 0) -> int:
    """Repeatedly XOR a stabilizer row when it lowers the weight. rounds=0: until fixpoint."""
    w = x.bit_count()
    r = 0
    while True:
        improved = False
        for s in stab_rows:
            y = x ^ s
            wy = y.bit_count()
            if wy < w:
                x, w, improved = y, wy, True
        r += 1
        if not improved or (rounds and r >= rounds):
            return w


def greedy_bound(logicals: list[int], stab_rows: list[int], max_classes: int | None = None,
                 rounds: int = 0, rng=None) -> int:
    """Smallest greedy weight over (all, or a random sample of) logical representatives."""
    reps = list(logicals)
    if max_classes is not None and max_classes < len(reps):
        rng = rng or np.random.default_rng(0)
        reps = [reps[i] for i in rng.choice(len(reps), max_classes, replace=False)]
    if not reps:                      # k = 0: no logical qubits, nothing to bound
        return 10 ** 6
    return min(greedy_descent(x, stab_rows, rounds) for x in reps)


def ip_min_weight(HZ: sp.csr_matrix, ell: np.ndarray, time_limit: float = 8.0):
    """min sum x  s.t.  HZ x = 2t, ell.x = 2s+1, x binary, t,s >= 0 integer.
    Returns dict(best=weight or None, dual=lower bound, optimal=bool).  `best` is an
    UPPER bound on the minimum weight of an X-type logical anticommuting with ell."""
    HZ = sp.csr_matrix(HZ, dtype=float)
    m, n = HZ.shape
    ell = sp.csr_matrix(np.asarray(ell, dtype=float).reshape(1, -1))
    A = sp.vstack([sp.hstack([HZ, -2 * sp.identity(m), sp.csr_matrix((m, 1))]),
                   sp.hstack([ell, sp.csr_matrix((1, m)), sp.csr_matrix([[-2.0]])])]).tocsr()
    lb = np.concatenate([np.zeros(m), [1.0]])
    cons = LinearConstraint(A, lb, lb)
    cost = np.concatenate([np.ones(n), np.zeros(m + 1)])
    tmax = np.asarray(HZ.sum(axis=1)).ravel() // 2
    ub = np.concatenate([np.ones(n), tmax, [float(n)]])
    res = milp(cost, constraints=cons, integrality=np.ones(n + m + 1),
               bounds=Bounds(np.zeros(n + m + 1), ub),
               options={"time_limit": float(time_limit), "disp": False})
    best = None
    if res.x is not None:
        x = np.round(res.x[:n]).astype(np.uint8)
        best = int(x.sum())
    dual = getattr(res, "mip_dual_bound", None)
    return {"best": best, "dual": None if dual is None else float(dual),
            "optimal": bool(res.status == 0), "status": int(res.status)}


def ip_distance_sample(code, kind: str, n_classes: int, time_limit: float, rng) -> dict:
    """IP over a sample of logical classes. kind='x': X-type logicals, anticommuting with the
    j-th Z-type logical (rows of code.logical_z); kind='z': the symmetric problem."""
    if kind == "x":
        H, L = code.HZ, code.logical_dense("z")
    else:
        H, L = code.HX, code.logical_dense("x")
    k = L.shape[0]
    idx = np.arange(k) if n_classes >= k else rng.choice(k, n_classes, replace=False)
    out = [ip_min_weight(H, L[j], time_limit) for j in idx]
    feas = [o["best"] for o in out if o["best"] is not None]
    return {"classes": len(idx), "feasible": len(feas), "none": len(idx) - len(feas),
            "optimal": sum(o["optimal"] for o in out),
            "best": min(feas) if feas else None,
            "median": float(np.median(feas)) if feas else None,
            "max_dual": max((o["dual"] or 0) for o in out), "per_class": [o["best"] for o in out]}
