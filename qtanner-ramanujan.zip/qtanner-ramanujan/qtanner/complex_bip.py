"""Standard bipartite left-right Cayley complex of PGL(2,q): V0 = PSL(2,q), V1 = PGL \\ PSL."""
from .complex_dc import build_complex, Complex


def build_bipartite(G, A, B) -> Complex:
    return build_complex(G, A, B, bipartite=True)
