"""GF(2) linear algebra on bit-packed rows (Python integers)."""
from __future__ import annotations
import numpy as np
import scipy.sparse as sp


def csr_to_ints(M) -> list[int]:
    M = sp.csr_matrix(M)
    out = []
    for i in range(M.shape[0]):
        v = 0
        for c in M.indices[M.indptr[i]:M.indptr[i + 1]]:
            v ^= 1 << int(c)
        out.append(v)
    return out


def ints_to_dense(rows: list[int], n: int) -> np.ndarray:
    M = np.zeros((len(rows), n), dtype=np.uint8)
    for i, v in enumerate(rows):
        while v:
            low = v & -v
            M[i, low.bit_length() - 1] = 1
            v ^= low
    return M


class XorBasis:
    """Incremental basis keyed by leading bit."""
    def __init__(self, rows=()):
        self.piv: dict[int, int] = {}
        for r in rows:
            self.add(r)

    def reduce(self, v: int) -> int:
        while v:
            h = v.bit_length() - 1
            b = self.piv.get(h)
            if b is None:
                return v
            v ^= b
        return 0

    def add(self, v: int) -> bool:
        v = self.reduce(v)
        if v:
            self.piv[v.bit_length() - 1] = v
            return True
        return False

    def __len__(self):
        return len(self.piv)


def rank(rows: list[int]) -> int:
    return len(XorBasis(rows))


def kernel(rows: list[int], n: int) -> list[int]:
    """Basis of {x : <row,x> = 0 for all rows} as ints, via reduced row echelon form."""
    piv: dict[int, int] = {}          # pivot column (lowest set bit) -> row
    for r in rows:
        for c, b in piv.items():
            if (r >> c) & 1:
                r ^= b
        if r:
            c = (r & -r).bit_length() - 1
            for c2 in list(piv):
                if (piv[c2] >> c) & 1:
                    piv[c2] ^= r
            piv[c] = r
    free = [c for c in range(n) if c not in piv]
    # column -> pivots whose row contains it
    ker = []
    pivrows = list(piv.items())
    for f in free:
        v = 1 << f
        for c, b in pivrows:
            if (b >> f) & 1:
                v |= 1 << c
        ker.append(v)
    return ker
