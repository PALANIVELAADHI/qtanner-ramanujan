"""Statistics helpers: Wilson intervals, bootstrap, Cliff's delta, BH correction, permutation."""
from __future__ import annotations
import numpy as np
from scipy import stats as st


def wilson(k: int, n: int, z: float = 1.959964):
    if n == 0:
        return (0.0, 1.0)
    ph = k / n
    den = 1 + z * z / n
    c = (ph + z * z / (2 * n)) / den
    h = z * np.sqrt(ph * (1 - ph) / n + z * z / (4 * n * n)) / den
    return float(max(0, c - h)), float(min(1, c + h))


def bootstrap_ci(x, stat=np.median, B: int = 5000, alpha: float = 0.05, rng=None):
    rng = rng or np.random.default_rng(0)
    x = np.asarray(x, dtype=float)
    bs = [stat(rng.choice(x, len(x), replace=True)) for _ in range(B)]
    return float(np.quantile(bs, alpha / 2)), float(np.quantile(bs, 1 - alpha / 2))


def cliffs_delta(x, y) -> float:
    x, y = np.asarray(x, float), np.asarray(y, float)
    return float((np.sum(x[:, None] > y[None, :]) - np.sum(x[:, None] < y[None, :])) / (len(x) * len(y)))


def bh_adjust(pvals):
    p = np.asarray(pvals, float)
    m = len(p)
    order = np.argsort(p)
    adj = np.empty(m)
    prev = 1.0
    for rank, i in zip(range(m, 0, -1), order[::-1]):
        prev = min(prev, p[i] * m / rank)
        adj[i] = prev
    return adj


def stratified_permutation(groups, n_perm: int = 10000, rng=None):
    """groups: list of (x, y) arrays. Statistic: n-weighted mean within-group Spearman.
    y is permuted within each group. Returns (stat, two-sided p)."""
    rng = rng or np.random.default_rng(0)
    def stat(ys):
        ws = [len(x) for x, _ in groups]
        rs = [st.spearmanr(x, y)[0] for (x, _), y in zip(groups, ys)]
        return float(np.average(np.nan_to_num(rs), weights=ws))
    obs = stat([y for _, y in groups])
    cnt = sum(abs(stat([rng.permutation(y) for _, y in groups])) >= abs(obs) - 1e-12
              for _ in range(n_perm))
    return obs, (cnt + 1) / (n_perm + 1)
