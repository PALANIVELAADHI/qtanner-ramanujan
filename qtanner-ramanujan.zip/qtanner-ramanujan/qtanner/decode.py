"""Code-capacity noise, BP / BP+OSD decoding (ldpc 2.x) and failure statistics."""
from __future__ import annotations
import time
import numpy as np
import scipy.sparse as sp
from ldpc import BpDecoder
from ldpc.bposd_decoder import BpOsdDecoder
from .stats import wilson


def make_decoder(H, p: float, method: str = "osd0", ms_factor: float = 0.625, max_iter: int = 60):
    """method in {'bp','osd0','oscs'} (min-sum, scaling `ms_factor`, <= `max_iter` iterations)."""
    H = sp.csr_matrix(H, dtype=np.uint8)
    if method == "bp":
        return BpDecoder(H, error_rate=p, max_iter=max_iter, bp_method="minimum_sum",
                         ms_scaling_factor=ms_factor)
    if method == "osd0":
        return BpOsdDecoder(H, error_rate=p, max_iter=max_iter, bp_method="minimum_sum",
                            ms_scaling_factor=ms_factor, osd_method="osd_0", osd_order=0)
    if method == "oscs":
        return BpOsdDecoder(H, error_rate=p, max_iter=max_iter, bp_method="minimum_sum",
                            ms_scaling_factor=ms_factor, osd_method="osd_cs", osd_order=7)
    raise ValueError(method)


def _fail(H, L, e, c) -> bool:
    r = (e ^ c).astype(np.uint8)
    if (H @ r % 2).any():
        return True
    return bool((L @ r % 2).any())


def block_failure(code, p: float, shots: int, rng, noise: str = "x", method: str = "osd0",
                  ms_factor: float = 0.625, max_iter: int = 60, weight: int | None = None):
    """Block failure rate. noise='x': X errors decoded with H_Z, failure tested with the
    Z-type logicals.  noise='z': Z errors, H_X, X-type logicals.  `weight` => fixed-weight errors.
    A block fails if ANY logical qubit is corrupted. Returns dict with Wilson 95% interval."""
    H = code.HZ if noise == "x" else code.HX
    L = code.logical_dense("z" if noise == "x" else "x")
    dec = make_decoder(H, p if weight is None else max(weight / code.n, 1e-4), method,
                       ms_factor, max_iter)
    fails, t0 = 0, time.perf_counter()
    for _ in range(shots):
        if weight is None:
            e = (rng.random(code.n) < p).astype(np.uint8)
        else:
            e = np.zeros(code.n, dtype=np.uint8)
            e[rng.choice(code.n, weight, replace=False)] = 1
        s = (H @ e % 2).astype(np.uint8)
        c = np.asarray(dec.decode(s)).astype(np.uint8)
        fails += _fail(H, L, e, c)
    dt = (time.perf_counter() - t0) / shots
    lo, hi = wilson(fails, shots)
    return {"p": p, "shots": shots, "fails": int(fails), "rate": fails / shots,
            "lo": lo, "hi": hi, "sec_per_shot": dt, "k": int(L.shape[0])}
