"""CSS quantum Tanner code from a complex and two local codes."""
from __future__ import annotations
from dataclasses import dataclass, field
import numpy as np
import scipy.sparse as sp
from .complex_dc import Complex
from .localcodes import LocalCode
from . import gf2


def _assemble(view: np.ndarray, local: np.ndarray, n: int) -> sp.csr_matrix:
    """Place the local generator rows (r x dA*dB) on every vertex view."""
    V = view.shape[0]
    flat = view.reshape(V, -1)
    r = local.shape[0]
    rows, cols = [], []
    for j in range(r):
        supp = np.nonzero(local[j])[0]
        rows.append(np.repeat(np.arange(V) * r + j, len(supp)))
        cols.append(flat[:, supp].ravel())
    rows, cols = np.concatenate(rows), np.concatenate(cols)
    M = sp.coo_matrix((np.ones(len(rows), dtype=np.uint8), (rows, cols)),
                      shape=(V * r, n)).tocsr()
    M.data %= 2
    M.eliminate_zeros()
    return M


def _tensor_rows(RA: np.ndarray, RB: np.ndarray) -> np.ndarray:
    return np.array([np.outer(a, b).ravel() for a in RA for b in RB], dtype=np.uint8) \
        if len(RA) and len(RB) else np.zeros((0, RA.shape[1] * RB.shape[1]), dtype=np.uint8)


@dataclass
class QuantumTannerCode:
    cx: Complex
    CA: LocalCode
    CB: LocalCode
    HX: sp.csr_matrix = field(repr=False)
    HZ: sp.csr_matrix = field(repr=False)
    n: int = 0
    _logical: dict = field(default_factory=dict, repr=False)

    # --- construction ---------------------------------------------------------
    @classmethod
    def build(cls, cx: Complex, CA: LocalCode, CB: LocalCode, verify: bool = True):
        n = cx.n
        # X checks: basis of C_A (x) C_B on every V0 view
        LX = _tensor_rows(CA.G, CB.G)
        # Z checks: basis of sigma(C_A^perp) (x) C_B^perp on every V1 view,
        # (sigma g)_a = g_{a^-1}
        LZ = _tensor_rows(CA.H[:, cx.invA], CB.H)
        HX = _assemble(cx.view0, LX, n)
        HZ = _assemble(cx.view1, LZ, n)
        code = cls(cx, CA, CB, HX, HZ, n)
        if verify and not code.commutes():
            raise AssertionError("H_X H_Z^T != 0")
        return code

    def commutes(self) -> bool:
        P = (self.HX @ self.HZ.T)
        P.data %= 2
        P.eliminate_zeros()
        return P.nnz == 0

    # --- parameters -----------------------------------------------------------
    @property
    def rows_x(self): return self._cached("rows_x", lambda: gf2.csr_to_ints(self.HX))
    @property
    def rows_z(self): return self._cached("rows_z", lambda: gf2.csr_to_ints(self.HZ))

    def _cached(self, key, fn):
        if key not in self._logical:
            self._logical[key] = fn()
        return self._logical[key]

    @property
    def k(self) -> int:
        return self.n - gf2.rank(self.rows_x) - gf2.rank(self.rows_z)

    def counting_bound_k(self) -> int:
        dA, dB, kA, kB = self.CA.n, self.CB.n, self.CA.k, self.CB.k
        return int(self.cx.group.N * (dA * dB / 2 - kA * kB - (dA - kA) * (dB - kB))) \
            if self.cx.kind == "double_cover" else int(
                (self.cx.view0.shape[0]) * (dA * dB / 2 - kA * kB - (dA - kA) * (dB - kB)))

    def weights(self) -> dict:
        f = lambda M, ax: int(np.asarray(M.sum(axis=ax)).max())
        return {"row_x": f(self.HX, 1), "row_z": f(self.HZ, 1),
                "col_x": f(self.HX, 0), "col_z": f(self.HZ, 0)}

    # --- logical operators ----------------------------------------------------
    def _logicals(self, stab_rows: list[int], check_rows: list[int]) -> list[int]:
        """Kernel of `check_rows` modulo rowspace(stab_rows): a basis of k logical reps."""
        basis = gf2.XorBasis(stab_rows)
        out = []
        for v in gf2.kernel(check_rows, self.n):
            if basis.add(v):
                out.append(v)
        return out

    @property
    def logical_x(self) -> list[int]:
        """X-type logicals: ker H_Z modulo rowspace H_X (bit-packed ints)."""
        return self._cached("lx", lambda: self._logicals(self.rows_x, self.rows_z))

    @property
    def logical_z(self) -> list[int]:
        """Z-type logicals: ker H_X modulo rowspace H_Z."""
        return self._cached("lz", lambda: self._logicals(self.rows_z, self.rows_x))

    def logical_dense(self, kind: str) -> np.ndarray:
        rows = self.logical_z if kind == "z" else self.logical_x
        return gf2.ints_to_dense(rows, self.n)
