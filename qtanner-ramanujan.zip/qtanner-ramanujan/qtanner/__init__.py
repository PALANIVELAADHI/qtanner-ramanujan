"""qtanner: finite-size quantum Tanner codes on PSL(2,q) / PGL(2,q) Cayley complexes."""
__version__ = "1.0.0"
