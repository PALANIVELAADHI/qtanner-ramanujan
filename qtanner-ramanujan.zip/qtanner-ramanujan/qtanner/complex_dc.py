"""Left-right Cayley complex: squares and local views.

Double cover (G = PSL(2,q), V0 = G x {0}, V1 = G x {1}):
    square = [(g,a,b)] = [(a g b, a^-1, b^-1)],  vertices (g,0),(ag,1),(gb,1),(agb,0).
    V0 view of (g,0):  (a,b) -> [(g,a,b)]
    V1 view of (h,1):  (a,b) -> [(a^-1 h, a, b)]
The bipartite variant (complex_bip.py) restricts g to an index-2 subgroup G0.
"""
from __future__ import annotations
from dataclasses import dataclass
import numpy as np
from .group import Group


@dataclass
class Complex:
    group: Group
    A: np.ndarray
    B: np.ndarray
    n: int                 # number of squares (= qubits)
    view0: np.ndarray      # (|V0|, dA, dB) square ids
    view1: np.ndarray      # (|V1|, dA, dB) square ids
    invA: np.ndarray       # index of a^-1 in A
    invB: np.ndarray       # index of b^-1 in B
    kind: str


def _squares(G: Group, A, B, S0: np.ndarray):
    """Canonical square ids for triples (g,a,b), g in S0 (array of group elements)."""
    dA, dB = len(A), len(B)
    posA = {int(a): i for i, a in enumerate(A)}
    posB = {int(b): i for i, b in enumerate(B)}
    invA = np.array([posA[int(G.inv[a])] for a in A])
    invB = np.array([posB[int(G.inv[b])] for b in B])
    pos0 = -np.ones(G.N, dtype=np.int64)
    pos0[S0] = np.arange(len(S0))
    g = S0[:, None, None]
    a = np.asarray(A)[None, :, None]
    b = np.asarray(B)[None, None, :]
    agb = G.mult[G.mult[a, g], b]                                  # (|S0|,dA,dB)
    flat = (np.arange(len(S0))[:, None, None] * dA + np.arange(dA)[None, :, None]) * dB \
        + np.arange(dB)[None, None, :]
    partner = (pos0[agb] * dA + invA[None, :, None]) * dB + invB[None, None, :]
    if (partner < 0).any():
        raise ValueError("a g b left the vertex class S0 (wrong coset structure)")
    if (partner == flat).any():
        raise ValueError("fixed square: A and B contain conjugate elements")
    canon = np.minimum(flat, partner)
    ids = -np.ones(len(S0) * dA * dB, dtype=np.int64)
    uniq = np.unique(canon)
    ids[uniq] = np.arange(len(uniq))
    sq = ids[canon.ravel()].reshape(canon.shape)
    return sq, len(uniq), invA, invB, pos0


def build_complex(G: Group, A, B, bipartite: bool = False) -> Complex:
    A = np.asarray(A, dtype=np.int32)
    B = np.asarray(B, dtype=np.int32)
    if bipartite:
        if G.odd is None:
            raise ValueError("bipartite variant needs PGL(2,q)")
        if not (G.odd[A].all() and G.odd[B].all()):
            raise ValueError("A and B must lie outside the index-2 subgroup")
        S0 = np.where(~G.odd)[0].astype(np.int32)       # V0 = G0
        S1 = np.where(G.odd)[0].astype(np.int32)        # V1 = G \ G0
    else:
        S0 = np.arange(G.N, dtype=np.int32)
        S1 = S0
    sq, n, invA, invB, pos0 = _squares(G, A, B, S0)
    # V1 view: (a,b) -> [(a^-1 h, a, b)]
    h = S1[:, None, None]
    a = A[None, :, None]
    gg = G.mult[G.inv[a], h]                              # (|V1|,dA,1) group element in S0
    p = pos0[gg]                                          # position of a^-1 h in S0
    if (p < 0).any():
        raise ValueError("a^-1 h not in V0")
    b_idx = np.arange(len(B))[None, None, :]
    a_idx = np.arange(len(A))[None, :, None]
    view1 = sq[p, a_idx, b_idx]
    return Complex(G, A, B, n, sq, view1, invA, invB, "bipartite" if bipartite else "double_cover")
