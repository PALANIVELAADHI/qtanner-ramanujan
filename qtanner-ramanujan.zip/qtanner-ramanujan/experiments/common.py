"""Shared helpers for all experiment scripts."""
import argparse, json, os, sys, time
import numpy as np
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from qtanner.group import PSL, PGL
from qtanner.generators import sample_pair, spectral_ratio
from qtanner.localcodes import best_local_code
from qtanner.complex_dc import build_complex
from qtanner.code import QuantumTannerCode
from qtanner.distance import greedy_bound

DATA = os.path.join(os.path.dirname(__file__), "..", "data")
os.makedirs(DATA, exist_ok=True)

# name -> (q, Delta, kA, kB)  : the five main instance families of the paper
FAMILIES = {
    "QT-1080": (5, 6, 4, 2), "QT-1920": (5, 8, 5, 3), "QT-3000": (5, 10, 7, 3),
    "QT-3024": (7, 6, 4, 2), "QT-5376": (7, 8, 5, 3),
}


def parser(desc):
    ap = argparse.ArgumentParser(description=desc)
    ap.add_argument("--quick", action="store_true", help="tiny smoke-test sizes")
    ap.add_argument("--seed", type=int, default=None)
    return ap


def make_instance(q, delta, kA, kB, seed, variant="dc", local=None, sampler_seed=None):
    """Build one code instance. variant: 'dc' (double cover of PSL) or 'bip' (PGL bipartite).
    `local` = optional (CA, CB) to fix the local codes. Returns (code, meta)."""
    rng = np.random.default_rng(seed)
    G = PSL(q) if variant == "dc" else PGL(q)
    A, B = sample_pair(G, delta, rng, bipartite=(variant == "bip"))
    CA, CB = local if local else (best_local_code(delta, kA, rng), best_local_code(delta, kB, rng))
    code = QuantumTannerCode.build(build_complex(G, A, B, variant == "bip"), CA, CB)
    _, rA = spectral_ratio(G, A); _, rB = spectral_ratio(G, B)
    meta = dict(group=G.name, q=q, delta=delta, kA=kA, kB=kB, seed=seed, variant=variant,
                n=code.n, k=code.k, rhoA=rA, rhoB=rB, rho=max(rA, rB),
                local=dict(dA=CA.d, dAp=CA.dperp, dB=CB.d, dBp=CB.dperp))
    return code, meta


def greedy_all(code, rounds=0, max_classes=None, rng=None):
    gx = greedy_bound(code.logical_x, code.rows_x, max_classes, rounds, rng)
    gz = greedy_bound(code.logical_z, code.rows_z, max_classes, rounds, rng)
    return gx, gz


def save(name, obj):
    path = os.path.join(DATA, name + ".json")
    with open(path, "w") as f:
        json.dump(obj, f, indent=1, default=lambda o: o.item() if hasattr(o, "item") else str(o))
    print("wrote", path)
