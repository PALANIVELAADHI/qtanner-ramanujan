"""R5: effect of local-code dimensions (kA,kB) at fixed Delta."""
from common import *
from qtanner.decode import block_failure
ap = parser(__doc__); ap.add_argument("--delta", type=int, default=8); a = ap.parse_args()
D = a.delta
pairs = {8: [(3, 5), (4, 4), (5, 3), (6, 2), (7, 1)], 6: [(2, 4), (3, 3), (4, 2), (5, 1)]}[D]
out = {}
for kA, kB in pairs:
    rows = []
    for i in range(2 if a.quick else 6):
        code, meta = make_instance(5, D, kA, kB, seed=7000 + 100 * kA + i)
        r = np.random.default_rng(i); gx, gz = greedy_all(code, max_classes=25, rng=r)
        meta.update(greedy=min(gx, gz), counting_bound=code.counting_bound_k(),
                    fail=[block_failure(code, p, 15 if a.quick else (250 if D == 8 else 300), r)["rate"] for p in (0.02, 0.03, 0.04)])
        rows.append(meta)
    out[f"{kA},{kB}"] = rows
    print((kA, kB), [m["k"] for m in rows], [m["fail"][1] for m in rows])
save(f"rate_sweep_D{D}", out)
