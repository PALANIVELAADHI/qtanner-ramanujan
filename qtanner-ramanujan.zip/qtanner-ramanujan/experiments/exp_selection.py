"""Instance selection: best of 8 draws (24 for QT-5376) by the greedy proxy min(dX,dZ);
selection check with integer programs (QT-1080, QT-1920). Writes the five selected instances."""
from common import *
from qtanner.distance import ip_distance_sample
ap = parser(__doc__); a = ap.parse_args()
out = {}
for name, (q, D, kA, kB) in FAMILIES.items():
    ndraw = 2 if a.quick else (24 if name == "QT-5376" else 8)
    cands = []
    for s in range(1, ndraw + 1):
        code, meta = make_instance(q, D, kA, kB, seed=1000 * D + 10 * q + s)
        rng = np.random.default_rng(s)
        gx, gz = greedy_all(code, rounds=3, max_classes=30, rng=rng)     # proxy (30 reps, 3 rounds)
        meta.update(proxy=min(gx, gz), greedy_x30=gx, greedy_z30=gz)
        if name in ("QT-1080", "QT-1920") and not a.quick:               # selection check
            gxa, gza = greedy_all(code)
            ipx = ip_distance_sample(code, "x", 3, 8, rng); ipz = ip_distance_sample(code, "z", 3, 8, rng)
            meta.update(greedy_all_x=gxa, greedy_all_z=gza, ip_x=ipx["best"], ip_z=ipz["best"])
        cands.append(meta); print(name, s, meta["k"], meta["proxy"])
    best = max(cands, key=lambda m: m["proxy"])
    out[name] = dict(selected=best, candidates=cands)
save("selection", out)
