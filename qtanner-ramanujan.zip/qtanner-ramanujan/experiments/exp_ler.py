"""Block logical error rates (BP+OSD-0) of the selected instances; X vs Z noise; decoder
comparison and fixed-weight decoding on request."""
from common import *
from qtanner.decode import block_failure
ap = parser(__doc__); ap.add_argument("--names", nargs="*", default=["QT-1080", "QT-1920", "QT-3024"])
ap.add_argument("--ms", type=float, default=0.625)
a = ap.parse_args()
sel = json.load(open(os.path.join(DATA, "selection.json")))
SHOTS = {"QT-1080": 2000, "QT-1920": 500, "QT-3024": 600, "QT-3000": 300, "QT-5376": 40}
out = {}
for name in a.names:
    q, D, kA, kB = FAMILIES[name]
    code, meta = make_instance(q, D, kA, kB, sel[name]["selected"]["seed"])
    rng = np.random.default_rng(7)
    sh = 4 if a.quick else SHOTS[name]
    ps = (0.01, 0.02, 0.03) if name == "QT-5376" else (0.01, 0.02, 0.03, 0.04, 0.05)   # cost: anecdotal only
    out[name] = dict(meta=meta, osd0=[block_failure(code, p, sh, rng, ms_factor=a.ms) for p in ps])
    if name == "QT-1920":
        out[name]["z_noise"] = [block_failure(code, p, sh, rng, noise="z") for p in (0.02, 0.03, 0.04, 0.05)]
        out[name]["bp"] = [block_failure(code, p, sh, rng, method="bp") for p in (0.02, 0.03, 0.04)]
        out[name]["oscs"] = [block_failure(code, p, sh, rng, method="oscs") for p in (0.02, 0.03, 0.04)]
    print(name, [round(r["rate"], 3) for r in out[name]["osd0"]])
save("ler" + ("" if a.ms == 0.625 else f"_ms{a.ms}"), out)
