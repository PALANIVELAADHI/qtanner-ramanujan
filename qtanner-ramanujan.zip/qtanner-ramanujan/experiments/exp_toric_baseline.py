"""Toric code + PyMatching reference curve (shape only; k=2)."""
from common import *
import pymatching, scipy.sparse as sp
ap = parser(__doc__); a = ap.parse_args(); out = {}
def toric(L):
    idx = lambda x, y, d: ((x % L) * L + (y % L)) * 2 + d      # edge (x,y,d): d=0 horizontal, 1 vertical
    H = sp.lil_matrix((L * L, 2 * L * L), dtype=np.uint8)
    for x in range(L):
        for y in range(L):
            v = x * L + y
            for e in (idx(x, y, 0), idx(x - 1, y, 0), idx(x, y, 1), idx(x, y - 1, 1)): H[v, e] ^= 1
    # logical Z-type operators: non-contractible loops on the dual lattice -> use homology rep
    Lg = np.zeros((2, 2 * L * L), dtype=np.uint8)
    for y in range(L): Lg[0, idx(0, y, 0)] = 1
    for x in range(L): Lg[1, idx(x, 0, 1)] = 1
    return H.tocsr(), Lg
for L in (4, 6, 8):
    H, Lg = toric(L); m = pymatching.Matching(H); rng = np.random.default_rng(L); out[L] = []
    for p in (0.06, 0.08, 0.10, 0.12, 0.14):
        sh = 200 if a.quick else 4000; f = 0
        for _ in range(sh):
            e = (rng.random(H.shape[1]) < p).astype(np.uint8); c = m.decode((H @ e % 2).astype(np.uint8))
            f += bool((Lg @ ((e ^ c) % 2) % 2).any())
        out[L].append(dict(p=p, rate=f / sh)); print(L, p, f / sh)
save("toric", out)
