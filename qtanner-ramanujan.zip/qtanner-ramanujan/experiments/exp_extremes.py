"""R14: best-rho vs worst-rho generating pairs, one family, fixed local codes."""
from common import *
from qtanner.decode import block_failure
from qtanner.distance import ip_distance_sample
from qtanner.stats import cliffs_delta, bootstrap_ci
from scipy.stats import mannwhitneyu
ap = parser(__doc__); a = ap.parse_args()
G = PSL(5); rng = np.random.default_rng(14)
CA, CB = best_local_code(6, 4, rng), best_local_code(6, 2, rng)
pairs = []
for _ in range(20 if a.quick else 400):
    A, B = sample_pair(G, 6, rng); pairs.append((A, B, max(spectral_ratio(G, A)[1], spectral_ratio(G, B)[1])))
pairs.sort(key=lambda t: t[2]); m = 2 if a.quick else 8
groups = {"best": pairs[:m], "worst": pairs[-m:]}
out = {}
for gname, grp in groups.items():
    rows = []
    for A, B, rho in grp:
        code = QuantumTannerCode.build(build_complex(G, A, B), CA, CB)
        gx, gz = greedy_all(code); r = np.random.default_rng(1)
        ip = min(v for v in (ip_distance_sample(code, t, 2, 8, r)["best"] for t in "xz") if v is not None) \
            if True else None
        f = block_failure(code, 0.03, 20 if a.quick else 400, r)
        rows.append(dict(rho=rho, greedy=min(gx, gz), ip=ip, k=code.k, fail_per_logical=f["rate"] / code.k, block_fail=f["rate"]))
    out[gname] = rows
for key in ("ip", "greedy", "block_fail"):
    x = [r[key] for r in out["best"] if r[key] is not None]; y = [r[key] for r in out["worst"] if r[key] is not None]
    print(key, "median best/worst", np.median(x), np.median(y), "MWU p=", mannwhitneyu(x, y).pvalue, "Cliff", cliffs_delta(x, y))
save("extremes", out)
