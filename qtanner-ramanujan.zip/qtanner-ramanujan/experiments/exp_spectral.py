"""R1: Ramanujan fraction and rho distribution of random symmetric sets; draw validity."""
from common import *
from qtanner.generators import random_symmetric_set, draw_validity_stats
ap = parser(__doc__); a = ap.parse_args()
rng = np.random.default_rng(a.seed or 1)
res, val = [], []
for q in (5, 7, 11, 13):
    G = PSL(q)
    for D in (4, 6, 8, 10):
        N = (6 if a.quick else (40 if q == 13 else 150))
        rho = []
        while len(rho) < N:
            S = random_symmetric_set(G, D, rng)
            if G.generates(S):
                rho.append(spectral_ratio(G, S)[1])
        res.append(dict(q=q, delta=D, order=G.N, frac_ramanujan=float(np.mean(np.array(rho) <= 1 + 1e-12)),
                        median_rho=float(np.median(rho)), rho=rho))
        val.append(draw_validity_stats(G, D, rng, 20 if a.quick else 400))
        print(q, D, res[-1]["frac_ramanujan"], res[-1]["median_rho"])
save("r1_spectral", res); save("r1_validity", val)
