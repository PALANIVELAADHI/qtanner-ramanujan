"""R11 + R19: 30 unselected instances per family, double cover vs PGL bipartite; failure rate
per logical qubit at p=0.03, greedy-detected small logicals (weight <= 8), IP on sampled classes."""
from common import *
from qtanner.decode import block_failure
from qtanner.distance import ip_distance_sample
ap = parser(__doc__); ap.add_argument("--variant", choices=["dc", "bip"], default="dc")
ap.add_argument("--ip", action="store_true", help="also run integer programs (3 classes/type, 8 s)")
a = ap.parse_args()
FAMS = {"1080": (5, 6, 4, 2), "1920": (5, 8, 5, 3), "3024": (7, 6, 4, 2)}
out = {}
for fam, (q, D, kA, kB) in FAMS.items():
    N = 2 if a.quick else 30
    shots = 4 if a.quick else (400 if a.variant == "dc" else 200)
    rows = []
    for i in range(N):
        seed = 300 + i + (1000 if a.variant == "bip" else 0)
        code, meta = make_instance(q, D, kA, kB, seed, variant=a.variant)
        rng = np.random.default_rng(seed)
        gx, gz = greedy_all(code, max_classes=25, rng=rng)
        r = block_failure(code, 0.03, shots, rng)
        meta.update(greedy_x=gx, greedy_z=gz, poor=int(min(gx, gz) <= 8), block_fail=r["rate"],
                    fail_per_logical=r["rate"] / code.k)
        if a.ip and i < (2 if a.quick else (10 if fam == "1080" else 4)):
            nc = 2 if fam == "3024" else 3
            meta["ip_x"] = ip_distance_sample(code, "x", nc, 8, rng)["best"]
            meta["ip_z"] = ip_distance_sample(code, "z", nc, 8, rng)["best"]
        rows.append(meta)
    out[fam] = rows
    print(fam, a.variant, "poor:", sum(r["poor"] for r in rows), "/", N)
save(f"unselected_{a.variant}", out)
