"""Association between spectral ratio and failure / distance proxy (Table 'stats')."""
from common import *
from scipy.stats import spearmanr
from qtanner.stats import stratified_permutation, bh_adjust
ap = parser(__doc__); a = ap.parse_args()
d = json.load(open(os.path.join(DATA, "unselected_dc.json")))
tests, groups_f, groups_d = [], [], []
for fam, rows in d.items():
    rho = np.array([r["rho"] for r in rows]); f = np.array([r["fail_per_logical"] for r in rows])
    g = np.array([min(r["greedy_x"], r["greedy_z"]) for r in rows])
    for lab, y in (("failure rate", f), ("distance proxy", g)):
        r_, p_ = spearmanr(rho, y); tests.append(dict(test=f"{fam}: rho vs {lab}", stat=r_, p=p_))
    groups_f.append((rho, f)); groups_d.append((rho, -g))
for lab, grp in (("failure rate", groups_f), ("distance proxy (sign flipped)", groups_d)):
    s, p = stratified_permutation(grp, 200 if a.quick else 10000); tests.append(dict(test="stratified rho vs " + lab, stat=s, p=p))
adj = bh_adjust([t["p"] for t in tests])
for t, p in zip(tests, adj): t["p_bh"] = float(p); print(t)
save("spectral_assoc", tests)
