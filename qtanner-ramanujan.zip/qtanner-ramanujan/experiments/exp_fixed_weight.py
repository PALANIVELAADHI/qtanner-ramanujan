"""Success probability of BP+OSD-0 versus error weight (150 shots/point)."""
from common import *
from qtanner.decode import block_failure
ap = parser(__doc__); a = ap.parse_args()
sel = json.load(open(os.path.join(DATA, "selection.json")))
out = {}
for name in ("QT-1080", "QT-1920", "QT-3024"):
    q, D, kA, kB = FAMILIES[name]
    code, meta = make_instance(q, D, kA, kB, sel[name]["selected"]["seed"])
    rng = np.random.default_rng(11); pts = []
    for frac in np.arange(0.01, 0.075, 0.01):
        w = int(round(frac * code.n))
        r = block_failure(code, 0.0, 10 if a.quick else 150, rng, weight=w)
        pts.append(dict(w=w, frac=float(frac), success=1 - r["rate"]))
    out[name] = pts; print(name, [round(x["success"], 2) for x in pts])
save("fixed_weight", out)
