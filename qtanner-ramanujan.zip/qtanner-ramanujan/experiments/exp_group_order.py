"""Anecdotal group-order scan: Delta=6,(4,2) at q=5 (3 inst, 300 shots) and q=7 (2 inst, 150 shots)."""
from common import *
from qtanner.decode import block_failure
ap = parser(__doc__); a = ap.parse_args(); out = {}
for q, ninst, shots in ((5, 3, 300), (7, 2, 150)):
    out[q] = []
    for i in range(ninst):
        code, meta = make_instance(q, 6, 4, 2, seed=9000 + 10 * q + i); r = np.random.default_rng(i)
        meta["curve"] = [block_failure(code, p, 10 if a.quick else shots, r)["rate"] / code.k for p in (0.01, 0.02, 0.03)]
        out[q].append(meta); print(q, meta["n"], meta["curve"])
save("group_order", out)
