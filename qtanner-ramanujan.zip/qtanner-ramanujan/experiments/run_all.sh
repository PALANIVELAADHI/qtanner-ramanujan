#!/usr/bin/env bash
# Regenerate every result (about 10 single-core CPU hours). Use  QUICK=1 ./run_all.sh  for a smoke test.
set -euo pipefail
cd "$(dirname "$0")"
Q=""; [ "${QUICK:-0}" = "1" ] && Q="--quick"
python exp_spectral.py $Q
python exp_selection.py $Q
python exp_milp_all.py $Q
python exp_ler.py $Q --names QT-1080 QT-1920 QT-3024 QT-3000 QT-5376
python exp_ler.py $Q --names QT-1080 QT-1920 QT-3024 --ms 0.75
python exp_decoder_tuning.py $Q
python exp_fixed_weight.py $Q
python exp_runtime.py $Q
python exp_unselected.py $Q --variant dc --ip
python exp_unselected.py $Q --variant bip --ip
python exp_spectral_assoc.py $Q
python exp_localq.py $Q
python exp_extremes.py $Q
python exp_rate_sweep.py $Q --delta 8
python exp_rate_sweep.py $Q --delta 6
python exp_group_order.py $Q
python exp_toric_baseline.py $Q
python make_figures.py
