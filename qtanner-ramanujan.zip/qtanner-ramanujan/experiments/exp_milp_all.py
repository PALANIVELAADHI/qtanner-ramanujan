"""IP over ALL logical classes of one instance (default QT-1080 selected instance)."""
from common import *
from qtanner.distance import ip_distance_sample
ap = parser(__doc__); ap.add_argument("--name", default="QT-1080"); ap.add_argument("--limit", type=float, default=6)
a = ap.parse_args()
sel = json.load(open(os.path.join(DATA, "selection.json")))[a.name]["selected"]
q, D, kA, kB = FAMILIES[a.name]
code, meta = make_instance(q, D, kA, kB, sel["seed"])
rng = np.random.default_rng(0)
nc = 3 if a.quick else 10 ** 9
gx, gz = greedy_all(code)
res = dict(meta=meta, greedy_x=gx, greedy_z=gz,
           x=ip_distance_sample(code, "x", nc, a.limit, rng), z=ip_distance_sample(code, "z", nc, a.limit, rng))
print(res["x"]["best"], res["z"]["best"], "greedy", gx, gz)
save("ip_all_" + a.name, res)
