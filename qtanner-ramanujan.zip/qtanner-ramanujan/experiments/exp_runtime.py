"""Decoding time per shot (p=0.03, 25 shots) and offline construction cost."""
from common import *
from qtanner.decode import block_failure
ap = parser(__doc__); a = ap.parse_args()
sel = json.load(open(os.path.join(DATA, "selection.json")))
out = {}
for name, (q, D, kA, kB) in FAMILIES.items():
    t = time.time(); code, meta = make_instance(q, D, kA, kB, sel[name]["selected"]["seed"]); tb = time.time() - t
    t = time.time(); code.logical_x; code.logical_z; tl = time.time() - t
    rng = np.random.default_rng(3); sh = 3 if a.quick else 25
    out[name] = dict(n=code.n, build_s=tb, logical_s=tl,
                     **{m: block_failure(code, 0.03, sh, rng, method=m)["sec_per_shot"] for m in ("bp", "osd0", "oscs")})
    print(name, out[name])
save("runtime", out)
