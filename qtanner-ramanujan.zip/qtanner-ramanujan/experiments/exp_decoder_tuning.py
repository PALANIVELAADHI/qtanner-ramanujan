"""Sensitivity of failure rate to the min-sum scaling factor (QT-1080 and hold-out QT-1920)."""
from common import *
from qtanner.decode import block_failure
ap = parser(__doc__); a = ap.parse_args()
sel = json.load(open(os.path.join(DATA, "selection.json"))); out = {}
for name, shots in (("QT-1080", 800), ("QT-1920", 500)):
    q, D, kA, kB = FAMILIES[name]
    code, _ = make_instance(q, D, kA, kB, sel[name]["selected"]["seed"])
    out[name] = {}
    for ms in (0.5, 0.625, 0.75, 0.9, 1.0):
        r = block_failure(code, 0.03, 20 if a.quick else shots, np.random.default_rng(2), ms_factor=ms)
        out[name][str(ms)] = r; print(name, ms, r["rate"])
save("decoder_tuning", out)
