"""Generate result figures from data/*.json (skips figures whose data are missing).
The conceptual figures (architecture, local geometry) are drawn by hand in the paper; the
radius-two complex ball is generated here."""
import json, os, sys
import numpy as np
import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
D = os.path.join(os.path.dirname(__file__), "..", "data"); F = os.path.join(os.path.dirname(__file__), "..", "figures")
os.makedirs(F, exist_ok=True)
load = lambda n: json.load(open(os.path.join(D, n + ".json"))) if os.path.exists(os.path.join(D, n + ".json")) else None
done = lambda n: (plt.tight_layout(), plt.savefig(os.path.join(F, n + ".png"), dpi=200), plt.close(), print("figure", n))

d = load("r1_spectral")
if d:
    fig, ax = plt.subplots(1, 2, figsize=(10, 3.6))
    for D_ in sorted({r["delta"] for r in d}):
        rr = [r for r in d if r["delta"] == D_]; ax[0].plot([r["order"] for r in rr], [r["frac_ramanujan"] for r in rr], "o-", label=f"$\\Delta$={D_}")
    ax[0].set(xscale="log", xlabel="|G|", ylabel="fraction Ramanujan"); ax[0].legend()
    rr = [r for r in d if r["delta"] == 8]; ax[1].boxplot([r["rho"] for r in rr], labels=[r["order"] for r in rr]); ax[1].axhline(1, ls="--", c="k"); ax[1].set(xlabel="|G|", ylabel=r"$\rho$")
    done("fig_r1_spectral")

d = load("ler")
if d:
    plt.figure(figsize=(5, 3.6))
    for n, v in d.items():
        plt.errorbar([r["p"] for r in v["osd0"]], [r["rate"] for r in v["osd0"]], [[max(r["rate"] - r["lo"], 0) for r in v["osd0"]], [max(r["hi"] - r["rate"], 0) for r in v["osd0"]]], marker="o", label=n)
    plt.yscale("log"); plt.xlabel("p"); plt.ylabel("block failure"); plt.legend(); done("fig_r3_ler")

d = load("fixed_weight")
if d:
    plt.figure(figsize=(4.5, 3.4))
    for n, v in d.items(): plt.plot([x["frac"] for x in v], [x["success"] for x in v], "o-", label=n)
    plt.xlabel("error weight / n"); plt.ylabel("success"); plt.legend(); done("fig_r9_weight")

for var in ("dc", "bip"):
    pass
dc, bp = load("unselected_dc"), load("unselected_bip")
if dc:
    fig, ax = plt.subplots(1, 2, figsize=(9, 3.4)); fams = list(dc)
    for off, (lab, dd) in enumerate((("double cover", dc), ("bipartite PGL", bp))):
        if not dd: continue
        ax[0].bar(np.arange(3) + 0.4 * off, [np.mean([r["poor"] for r in dd[f]]) for f in fams], 0.4, label=lab)
        ax[1].boxplot([[r["fail_per_logical"] for r in dd[f]] for f in fams], positions=np.arange(3) + 0.4 * off, widths=0.3)
    ax[0].set_xticks(np.arange(3) + 0.2); ax[0].set_xticklabels(fams); ax[0].set(ylabel="fraction with greedy logical wt<=8"); ax[0].legend()
    ax[1].set_yscale("log"); ax[1].set_xticks(np.arange(3) + 0.2); ax[1].set_xticklabels(fams); ax[1].set(ylabel="failure / k at p=0.03")
    done("fig_r11_r19_unselected")

d = load("localq")
if d and d["levels"]:
    ks = [k for k, v in d["levels"].items() if v]
    fig, ax = plt.subplots(1, 2, figsize=(8, 3.4))
    ax[0].boxplot([[r["block_fail"] for r in d["levels"][k]] for k in ks], labels=ks); ax[0].set(xlabel="local-code score", ylabel="block failure, p=0.03")
    ax[1].boxplot([[r["greedy"] for r in d["levels"][k]] for k in ks], labels=ks); ax[1].set(xlabel="local-code score", ylabel="greedy bound", yscale="log")
    done("fig_r15_local_quality")

d = load("extremes")
if d:
    fig, ax = plt.subplots(1, 3, figsize=(10, 3.2))
    for a_, key in zip(ax, ("block_fail", "greedy", "ip")):
        a_.boxplot([[r[key] for r in d[g] if r[key] is not None] for g in ("best", "worst")], labels=["best rho", "worst rho"]); a_.set_title(key)
    done("fig_r14_extremes")

# radius-two ball of the double cover of PSL(2,5), Delta=4
sys.path.insert(0, os.path.dirname(__file__))
try:
    import networkx as nx
    from qtanner.group import PSL
    from qtanner.generators import sample_pair
    G = PSL(5); A, B = sample_pair(G, 4, np.random.default_rng(3)); e = G.identity
    g = nx.Graph(); frontier = {e}; seen = {e}
    for _ in range(2):
        nxt = set()
        for x in frontier:
            for a in A: g.add_edge(x, int(G.mult[a, x]), t="A"); nxt.add(int(G.mult[a, x]))
            for b in B: g.add_edge(x, int(G.mult[x, b]), t="B"); nxt.add(int(G.mult[x, b]))
        frontier = nxt - seen; seen |= nxt
    plt.figure(figsize=(5, 5)); pos = nx.spring_layout(g, seed=1)
    nx.draw_networkx_edges(g, pos, edgelist=[u for u in g.edges if g.edges[u]["t"] == "A"], edge_color="green", alpha=.6)
    nx.draw_networkx_edges(g, pos, edgelist=[u for u in g.edges if g.edges[u]["t"] == "B"], edge_color="orange", alpha=.6)
    nx.draw_networkx_nodes(g, pos, node_size=30, node_color="k"); plt.axis("off"); done("fig_complex_ball")
except Exception as ex:
    print("ball figure skipped:", ex)
