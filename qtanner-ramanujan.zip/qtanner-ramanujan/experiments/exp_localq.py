"""R15/R18: local-code quality levels and one-distance-lowered sweep (PSL(2,5), Delta=8, (5,3))."""
from common import *
from qtanner.localcodes import local_code_pool
from qtanner.decode import block_failure
ap = parser(__doc__); a = ap.parse_args()
rng = np.random.default_rng(15)
npool = 200 if a.quick else 5000
poolA = local_code_pool(8, 5, npool, rng); poolB = local_code_pool(8, 3, npool, rng)
def pick(pool, d, dp):
    c = [x for x in pool if (x.d, x.dperp) == (d, dp)]
    return c
# (d_A, d_A^perp), (d_B, d_B^perp) for the four levels of the paper's Table (score = sum)
LEVELS = {12: ((2, 4), (4, 2)), 10: ((2, 2), (4, 2)), 7: ((2, 2), (2, 1)), 4: ((1, 1), (1, 1))}
SINGLE = {"baseline": ((2, 4), (4, 2)), "dA-1": ((1, 4), (4, 2)), "dAp-1": ((2, 3), (4, 2)),
          "dB-1": ((2, 4), (3, 2)), "dBp-1": ((2, 4), (4, 1))}
out = {"levels": {}, "single": {}}
for tag, table in (("levels", LEVELS), ("single", SINGLE)):
    for lvl, (ka, kb) in table.items():
        A_, B_ = pick(poolA, *ka), pick(poolB, *kb)
        if not A_ or not B_:
            print("no local code available for", lvl, ka, kb); out[tag][str(lvl)] = None; continue
        rows = []
        for i in range(2 if a.quick else 12):
            CA, CB = A_[i % len(A_)], B_[i % len(B_)]
            code, meta = make_instance(5, 8, 5, 3, seed=5000 + i, local=(CA, CB))
            r = np.random.default_rng(i)
            gx, gz = greedy_all(code, max_classes=40, rng=r)
            f = block_failure(code, 0.03, 4 if a.quick else 200, r)
            meta.update(greedy=min(gx, gz), poor=int(min(gx, gz) <= 8), block_fail=f["rate"], fail_per_logical=f["rate"] / code.k)
            rows.append(meta)
        out[tag][str(lvl)] = rows
        print(tag, lvl, np.median([m["block_fail"] for m in rows]), np.median([m["greedy"] for m in rows]))
save("localq", out)
